define({
  "_themeLabel": "Katlanabilir Tema",
  "_layout_default": "Varsayılan düzen",
  "_layout_layout1": "Düzen 1"
});