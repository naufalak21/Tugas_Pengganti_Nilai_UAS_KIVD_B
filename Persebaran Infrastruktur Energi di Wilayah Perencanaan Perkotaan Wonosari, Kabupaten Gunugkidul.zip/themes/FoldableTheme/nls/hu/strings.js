define({
  "_themeLabel": "Összecsukható stílus",
  "_layout_default": "Alapértelmezett elrendezés",
  "_layout_layout1": "1. elrendezés"
});